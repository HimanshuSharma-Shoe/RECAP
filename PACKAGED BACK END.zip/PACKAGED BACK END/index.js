import express from 'express';
import OpenAI from 'openai';
import cors from 'cors';


const app = express();
const openAI = new OpenAI();

app.use(cors({
  origin: 'http://localhost:3000'
}));
app.use(express.json());

//Handles incoming POST requests with bundled Request data
app.post('/api/generate-response', async (req, res) => {
  const { location, weather, interest } = req.body;
  let prompt;
  if (interest == "outdoor") {
    prompt = `Generate one ${interest} activity for ${location} with the following weather conditions in mind: ${weather}. Do not waffle or provide multiple options. Do not include the current weather.`;
  } else if (interest == "indoor") {
    prompt = `Generate one ${interest} activity for ${location} with the following weather in mind: ${weather}. Do not waffle or provide multiple options. Do not include the current weather.`;
  } else {
    return res.status(400).json({ error: 'Invalid interest type' });
  }
  //OpenAI API Response and sending back to client
  try {
    const response = await openAI.responses.create({
      model: "gpt-4o-mini-2024-07-18",
      input: prompt
    });
    res.json({
      response: response
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate response' });
  }
});


app.listen(3001, () => {
  console.log('Server running on http://localhost:3001');
});
